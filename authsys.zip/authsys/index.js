module.exports = require("./lib/twilio-auth-service");
